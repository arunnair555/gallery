<?php

$admin_user = "admin";
$admin_password = "1234";

$settings_page_title = "Photo Gallery";
$settings_page_description = "Photo Gallery";

// if you will change thumbnail width or height, then login to admin area and re-generate thumbnails
$settings_thumbnail_width = '160';
$settings_thumbnail_height = '100';

$settings_photo_width = '1200';
$settings_photo_height = '650';

$settings_secret = "iuai4334832987432@#&^%AWDAW";
$settings_gallery_version = "1.0.2";

?>